const pages = [...document.querySelectorAll('.page')];
const navLinks = [...document.querySelectorAll('.nav-link')];
const nav = document.getElementById('mainNav');
const menuToggle = document.getElementById('menuToggle');
const music = document.getElementById('backgroundMusic');
const soundBtn = document.getElementById('soundBtn');
const soundLabel = document.getElementById('soundLabel');
let musicOn = false;

function showPage() {
  const id = (location.hash || '#beranda').slice(1);
  const requested = document.getElementById(id);
  const target = pages.find(page => page.id === id) || requested?.closest('.page') || pages[0];
  pages.forEach(page => page.classList.toggle('active-page', page === target));
  navLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${target.id}`));
  nav.classList.remove('open');
  if (requested && requested !== target) {
    requestAnimationFrame(() => requested.scrollIntoView({behavior: 'smooth', block: 'start'}));
  } else {
    window.scrollTo({top: 0, behavior: 'smooth'});
  }
}
window.addEventListener('hashchange', showPage);
window.addEventListener('DOMContentLoaded', showPage);
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));

soundBtn.addEventListener('click', async () => {
  if (!musicOn) {
    try {
      await music.play();
      musicOn = true;
      soundLabel.textContent = 'Musik: ON';
      soundBtn.setAttribute('aria-label', 'Matikan musik');
    } catch (error) {
      soundLabel.textContent = 'Tambahkan musik';
    }
  } else {
    music.pause();
    musicOn = false;
    soundLabel.textContent = 'Musik: OFF';
    soundBtn.setAttribute('aria-label', 'Aktifkan musik');
  }
});

// Navigasi tujuh bagian diplomasi
const panels = [...document.querySelectorAll('.dip-panel')];
const tabs = [...document.querySelectorAll('.dip-tab')];
let dipIndex = 0;
const dipCount = document.getElementById('dipCount');
const prevDip = document.getElementById('prevDip');
const nextDip = document.getElementById('nextDip');
function setDip(index) {
  dipIndex = Math.max(0, Math.min(index, panels.length - 1));
  panels.forEach((panel, i) => panel.classList.toggle('active', i === dipIndex));
  tabs.forEach((tab, i) => tab.classList.toggle('active', i === dipIndex));
  dipCount.textContent = `${String(dipIndex + 1).padStart(2, '0')} / ${String(panels.length).padStart(2, '0')}`;
  prevDip.disabled = dipIndex === 0;
  nextDip.disabled = dipIndex === panels.length - 1;
}
tabs.forEach((tab, i) => tab.addEventListener('click', () => setDip(i)));
prevDip.addEventListener('click', () => setDip(dipIndex - 1));
nextDip.addEventListener('click', () => setDip(dipIndex + 1));

// Galeri foto dapat diperbesar
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
document.querySelectorAll('.gallery-grid img, .dip-layout img').forEach(img => {
  img.addEventListener('click', () => {
    lightboxImage.src = img.src;
    lightboxImage.alt = img.alt;
    lightbox.classList.add('open');
  });
});
function closeLightbox() { lightbox.classList.remove('open'); }
document.getElementById('closeLightbox').addEventListener('click', closeLightbox);
lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });
